**To delete a deployment group**

This example deletes a deployment group that is associated with the specified application.

Command::

  aws deploy delete-deployment-group --application-name WordPress_App --deployment-group-name WordPress_DG

Output::

  {
      "hooksNotCleanedUp": []
  }